"""Trading bot package for Binance Futures Testnet.

This package provides a modular CLI-based trading bot for placing orders
on the Binance Futures Testnet platform.

Modules:
    client: Binance API client with authentication
    orders: Order placement logic and retry mechanisms
    validators: Input validation for trading parameters
    logging_config: Logging setup and utilities
"""

__version__ = "1.0.0"
__author__ = "Trading Bot"

from bot.client import BinanceClient, BinanceAPIError
from bot.orders import OrderService, OrderResult
from bot.validators import ValidationError, validate_order_params

__all__ = [
    "BinanceClient",
    "BinanceAPIError", 
    "OrderService",
    "OrderResult",
    "ValidationError",
    "validate_order_params",
]
