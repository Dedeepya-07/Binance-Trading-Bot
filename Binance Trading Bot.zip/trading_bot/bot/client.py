"""Binance Futures API client module.

Provides a wrapper around the Binance Futures Testnet API with authentication,
request signing, and error handling.
"""

import hashlib
import hmac
import json
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import httpx

from config import Config
from bot.logging_config import log_api_error


class BinanceAPIError(Exception):
    """Custom exception for Binance API errors."""
    
    def __init__(self, message: str, code: Optional[int] = None, response: Optional[Dict] = None):
        super().__init__(message)
        self.code = code
        self.response = response or {}


class BinanceClient:
    """Binance Futures Testnet API client.
    
    Handles authentication via API key/secret, request signing, and provides
    methods for placing orders and checking account information.
    
    Attributes:
        config: Configuration object with API credentials
        client: HTTPX async client instance
        logger: Logger instance for request/response logging
    """
    
    def __init__(self, config: Config, logger=None):
        """Initialize the Binance client.
        
        Args:
            config: Configuration with API credentials
            logger: Optional logger instance
        """
        self.config = config
        self.logger = logger
        self.client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=30.0,
            follow_redirects=True,
            headers={
                "X-MBX-APIKEY": config.api_key,
                "Content-Type": "application/json"
            }
        )
    
    def _generate_signature(self, query_string: str) -> str:
        """Generate HMAC SHA256 signature for request authentication.
        
        Args:
            query_string: URL-encoded query string to sign
        
        Returns:
            Hexadecimal signature string
        """
        signature = hmac.new(
            self.config.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature
    
    def _build_signed_request(
        self,
        params: Dict[str, Any],
        timestamp: Optional[int] = None
    ) -> str:
        """Build signed query string from parameters.
        
        Args:
            params: Request parameters
            timestamp: Optional timestamp (auto-generated if not provided)
        
        Returns:
            Signed query string
        """
        if timestamp is None:
            timestamp = int(time.time() * 1000)
        
        params['timestamp'] = timestamp
        params['recvWindow'] = self.config.recv_window
        
        query_string = urlencode(params)
        signature = self._generate_signature(query_string)
        query_string += f"&signature={signature}"
        
        return query_string
    
    async def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = True
    ) -> Dict[str, Any]:
        """Make HTTP request to Binance API.
        
        Args:
            method: HTTP method (GET, POST, DELETE)
            endpoint: API endpoint path
            params: Request parameters
            signed: Whether to sign the request
        
        Returns:
            API response as dictionary
        
        Raises:
            BinanceAPIError: If API returns an error
            httpx.RequestError: For network errors
        """
        params = params or {}
        
        if self.logger:
            self.logger.debug(f"API REQUEST: {method} {endpoint} | Params: {params}")
        
        try:
            if signed:
                query_string = self._build_signed_request(params)
                url = f"{endpoint}?{query_string}"
                
                if method == "POST":
                    response = await self.client.post(url)
                elif method == "GET":
                    response = await self.client.get(url)
                elif method == "DELETE":
                    response = await self.client.delete(url)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")
            else:
                if method == "GET":
                    response = await self.client.get(endpoint, params=params)
                else:
                    raise ValueError(f"Unsigned {method} not supported")
            
            # Debug: log raw response
            raw_text = response.text
            if self.logger:
                self.logger.debug(f"API RAW RESPONSE: {response.status_code} | {raw_text[:500]}")
            
            response_data = response.json()
            
            if self.logger:
                self.logger.debug(f"API RESPONSE: {response.status_code} | {response_data}")
            
            # Check for API errors
            if response.status_code != 200:
                error_msg = response_data.get('msg', 'Unknown error')
                error_code = response_data.get('code')
                raise BinanceAPIError(
                    f"API Error {response.status_code}: {error_msg}",
                    code=error_code,
                    response=response_data
                )
            
            if 'code' in response_data and response_data['code'] < 0:
                error_msg = response_data.get('msg', 'Unknown error')
                error_code = response_data.get('code')
                raise BinanceAPIError(
                    f"API Error {error_code}: {error_msg}",
                    code=error_code,
                    response=response_data
                )
            
            return response_data
            
        except httpx.RequestError as e:
            if self.logger:
                log_api_error(self.logger, e, f"Request to {endpoint}")
            raise BinanceAPIError(f"Network error: {str(e)}") from e
        except json.JSONDecodeError as e:
            if self.logger:
                log_api_error(self.logger, e, f"JSON decode error for {endpoint}")
            raise BinanceAPIError(f"Invalid JSON response: {str(e)}") from e
    
    async def ping(self) -> Dict[str, Any]:
        """Test connectivity to the API.
        
        Returns:
            Empty dict on success
        """
        return await self._make_request("GET", "/api/v3/ping", signed=False)
    
    async def get_server_time(self) -> Dict[str, Any]:
        """Get server time.
        
        Returns:
            Dictionary with serverTime
        """
        return await self._make_request("GET", "/api/v3/time", signed=False)
    
    async def get_account_info(self) -> Dict[str, Any]:
        """Get account information.
        
        Returns:
            Account details including balances and positions
        """
        return await self._make_request("GET", "/api/v3/account")
    
    async def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: Optional[float] = None,
        stop_price: Optional[float] = None,
        time_in_force: str = "GTC"
    ) -> Dict[str, Any]:
        """Place a new order.
        
        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            order_type: Order type (MARKET, LIMIT, STOP_LIMIT)
            quantity: Order quantity
            price: Limit price (required for LIMIT orders)
            stop_price: Stop price (required for STOP_LIMIT orders)
            time_in_force: Time in force (GTC, IOC, FOK)
        
        Returns:
            Order response with orderId, status, etc.
        """
        params = {
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": quantity
        }
        
        if order_type == "LIMIT":
            params["price"] = price
            params["timeInForce"] = time_in_force
        elif order_type == "STOP_LIMIT":
            params["price"] = price
            params["stopPrice"] = stop_price
            params["timeInForce"] = time_in_force
        
        return await self._make_request("POST", "/api/v3/order", params)
    
    async def get_order_status(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Check order status.
        
        Args:
            symbol: Trading pair symbol
            order_id: Order ID to check
        
        Returns:
            Order status details
        """
        params = {
            "symbol": symbol,
            "orderId": order_id
        }
        return await self._make_request("GET", "/fapi/v1/order", params)
    
    async def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Cancel an order.
        
        Args:
            symbol: Trading pair symbol
            order_id: Order ID to cancel
        
        Returns:
            Cancellation response
        """
        params = {
            "symbol": symbol,
            "orderId": order_id
        }
        return await self._make_request("DELETE", "/api/v3/order", params)
    
    async def get_exchange_info(self) -> Dict[str, Any]:
        """Get exchange information including symbol details.
        
        Returns:
            Exchange info with symbols, filters, etc.
        """
        return await self._make_request("GET", "/api/v3/exchangeInfo", signed=False)
    
    async def close(self):
        """Close the HTTP client connection."""
        await self.client.aclose()
    
    async def __aenter__(self):
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
