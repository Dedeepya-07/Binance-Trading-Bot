"""Order management module.

Provides high-level order placement functions with validation, logging,
and retry mechanisms.
"""

import asyncio
from typing import Callable, Dict, Optional, Tuple
from dataclasses import dataclass

from bot.client import BinanceAPIError, BinanceClient
from bot.validators import ValidationError, validate_order_params
from bot.logging_config import log_order_request, log_order_response, log_api_error


@dataclass
class OrderResult:
    """Result of an order placement attempt.
    
    Attributes:
        success: Whether the order was placed successfully
        order_id: Order ID from Binance (None if failed)
        status: Order status (NEW, FILLED, etc.)
        executed_qty: Amount that was executed
        avg_price: Average fill price
        message: Human-readable result message
        raw_response: Complete API response
        error: Error message if failed
    """
    success: bool
    order_id: Optional[int] = None
    status: Optional[str] = None
    executed_qty: Optional[str] = None
    avg_price: Optional[str] = None
    message: str = ""
    raw_response: Optional[Dict] = None
    error: Optional[str] = None


class OrderService:
    """Service for placing and managing orders.
    
    Provides a clean interface for placing different order types with
    built-in validation, logging, and optional retry logic.
    
    Attributes:
        client: Binance API client
        logger: Logger instance
        max_retries: Maximum retry attempts for failed orders
        retry_delay: Delay between retries in seconds
    """
    
    def __init__(
        self,
        client: BinanceClient,
        logger,
        max_retries: int = 3,
        retry_delay: float = 1.0
    ):
        """Initialize the order service.
        
        Args:
            client: Binance API client instance
            logger: Logger instance
            max_retries: Maximum number of retry attempts
            retry_delay: Delay between retry attempts (seconds)
        """
        self.client = client
        self.logger = logger
        self.max_retries = max_retries
        self.retry_delay = retry_delay
    
    def _format_order_summary(self, result: OrderResult) -> str:
        """Format order result for display.
        
        Args:
            result: OrderResult to format
        
        Returns:
            Formatted summary string
        """
        if result.success:
            return (
                f"\n{'='*50}\n"
                f"✅ ORDER PLACED SUCCESSFULLY\n"
                f"{'='*50}\n"
                f"Order ID:    {result.order_id}\n"
                f"Status:      {result.status}\n"
                f"Executed:    {result.executed_qty}\n"
                f"Avg Price:   {result.avg_price if result.avg_price else 'N/A'}\n"
                f"{'='*50}"
            )
        else:
            return (
                f"\n{'='*50}\n"
                f"❌ ORDER FAILED\n"
                f"{'='*50}\n"
                f"Error: {result.error}\n"
                f"{'='*50}"
            )
    
    async def _place_order_with_retry(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: Optional[float] = None,
        stop_price: Optional[float] = None
    ) -> OrderResult:
        """Place order with retry mechanism.
        
        Args:
            symbol: Trading pair symbol
            side: Order side (BUY/SELL)
            order_type: Order type (MARKET/LIMIT/STOP_LIMIT)
            quantity: Order quantity
            price: Limit price (for LIMIT orders)
            stop_price: Stop price (for STOP_LIMIT orders)
        
        Returns:
            OrderResult with success status and details
        """
        last_error = None
        
        for attempt in range(1, self.max_retries + 1):
            try:
                if self.logger:
                    self.logger.info(f"Order attempt {attempt}/{self.max_retries}")
                
                response = await self.client.place_order(
                    symbol=symbol,
                    side=side,
                    order_type=order_type,
                    quantity=quantity,
                    price=price,
                    stop_price=stop_price
                )
                
                # Parse successful response
                order_id = response.get('orderId')
                status = response.get('status')
                executed_qty = response.get('executedQty', '0')
                avg_price = response.get('avgPrice')
                
                # Calculate avg price if not provided directly
                if avg_price == '0' or avg_price is None:
                    fills = response.get('fills', [])
                    if fills:
                        total_cost = sum(float(f['price']) * float(f['qty']) for f in fills)
                        total_qty = sum(float(f['qty']) for f in fills)
                        if total_qty > 0:
                            avg_price = str(total_cost / total_qty)
                
                result = OrderResult(
                    success=True,
                    order_id=order_id,
                    status=status,
                    executed_qty=executed_qty,
                    avg_price=avg_price,
                    message=f"Order placed successfully (ID: {order_id})",
                    raw_response=response
                )
                
                if self.logger:
                    log_order_response(self.logger, response, success=True)
                
                return result
                
            except BinanceAPIError as e:
                last_error = e
                if self.logger:
                    log_api_error(self.logger, e, f"Order attempt {attempt}")
                
                # Don't retry on validation errors
                if e.code in [-2010, -2011, -2013, -2014, -2015]:  # Insufficient margin, invalid order
                    break
                
                if attempt < self.max_retries:
                    self.logger.info(f"Retrying in {self.retry_delay}s...")
                    await asyncio.sleep(self.retry_delay)
            
            except Exception as e:
                last_error = e
                if self.logger:
                    log_api_error(self.logger, e, f"Unexpected error on attempt {attempt}")
                
                if attempt < self.max_retries:
                    await asyncio.sleep(self.retry_delay)
        
        # All retries exhausted
        error_msg = str(last_error) if last_error else "Unknown error"
        return OrderResult(
            success=False,
            error=error_msg,
            message=f"Failed after {self.max_retries} attempts"
        )
    
    async def market_order(
        self,
        symbol: str,
        side: str,
        quantity: float
    ) -> OrderResult:
        """Place a market order.
        
        Market orders are executed immediately at the best available price.
        
        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            quantity: Amount to buy/sell
        
        Returns:
            OrderResult with execution details
        """
        # Validate inputs
        try:
            validate_order_params(symbol, side, "MARKET", quantity)
        except ValidationError as e:
            if self.logger:
                self.logger.error(f"Validation failed: {e}")
            return OrderResult(success=False, error=str(e))
        
        # Log request
        if self.logger:
            log_order_request(self.logger, symbol, side, "MARKET", quantity)
        
        # Place order
        result = await self._place_order_with_retry(
            symbol=symbol.upper(),
            side=side.upper(),
            order_type="MARKET",
            quantity=quantity
        )
        
        # Print summary
        print(self._format_order_summary(result))
        
        return result
    
    async def limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        time_in_force: str = "GTC"
    ) -> OrderResult:
        """Place a limit order.
        
        Limit orders are executed at the specified price or better.
        
        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            quantity: Amount to buy/sell
            price: Limit price
            time_in_force: Order validity (GTC=Good Till Cancel, IOC=Immediate or Cancel, FOK=Fill or Kill)
        
        Returns:
            OrderResult with order details
        """
        # Validate inputs
        try:
            validate_order_params(symbol, side, "LIMIT", quantity, price)
        except ValidationError as e:
            if self.logger:
                self.logger.error(f"Validation failed: {e}")
            return OrderResult(success=False, error=str(e))
        
        # Log request
        if self.logger:
            log_order_request(self.logger, symbol, side, "LIMIT", quantity, price)
        
        # Place order
        result = await self._place_order_with_retry(
            symbol=symbol.upper(),
            side=side.upper(),
            order_type="LIMIT",
            quantity=quantity,
            price=price
        )
        
        # Print summary
        print(self._format_order_summary(result))
        
        return result
    
    async def stop_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        stop_price: float,
        time_in_force: str = "GTC"
    ) -> OrderResult:
        """Place a stop-limit order (BONUS FEATURE).
        
        Stop-limit orders become limit orders when the stop price is reached.
        Useful for stop-loss and take-profit strategies.
        
        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            quantity: Amount to buy/sell
            price: Limit price (execution price after stop triggers)
            stop_price: Stop price (trigger price)
            time_in_force: Order validity (GTC, IOC, FOK)
        
        Returns:
            OrderResult with order details
        """
        # Validate inputs
        try:
            validate_order_params(symbol, side, "STOP_LIMIT", quantity, price, stop_price)
        except ValidationError as e:
            if self.logger:
                self.logger.error(f"Validation failed: {e}")
            return OrderResult(success=False, error=str(e))
        
        # Log request
        if self.logger:
            log_order_request(self.logger, symbol, side, "STOP_LIMIT", quantity, price, stop_price)
        
        # Place order
        result = await self._place_order_with_retry(
            symbol=symbol.upper(),
            side=side.upper(),
            order_type="STOP",
            quantity=quantity,
            price=price,
            stop_price=stop_price
        )
        
        # Print summary
        print(self._format_order_summary(result))
        
        return result
    
    async def get_order_status(self, symbol: str, order_id: int) -> Dict:
        """Check the status of an existing order.
        
        Args:
            symbol: Trading pair symbol
            order_id: Order ID to check
        
        Returns:
            Order status information
        """
        try:
            return await self.client.get_order_status(symbol, order_id)
        except BinanceAPIError as e:
            if self.logger:
                log_api_error(self.logger, e, "Get order status")
            raise
