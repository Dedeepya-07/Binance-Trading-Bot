"""Logging configuration module.

Sets up structured logging to both console and file outputs.
"""

import logging
import logging.handlers
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


def setup_logging(
    log_level: str = "INFO",
    log_dir: Optional[str] = None,
    max_bytes: int = 10_485_760,  # 10MB
    backup_count: int = 5
) -> logging.Logger:
    """Configure logging for the trading bot.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_dir: Directory for log files (default: logs/ in project root)
        max_bytes: Maximum bytes per log file before rotation
        backup_count: Number of backup log files to keep
    
    Returns:
        Configured logger instance
    """
    # Determine log directory
    if log_dir is None:
        # Use project root / logs
        project_root = Path(__file__).parent.parent.absolute()
        log_dir = project_root / "logs"
    else:
        log_dir = Path(log_dir)
    
    # Create log directory if it doesn't exist
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # Create log file path with date
    log_file = log_dir / "app.log"
    
    # Configure root logger
    logger = logging.getLogger("trading_bot")
    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    
    # Remove existing handlers to avoid duplicates
    logger.handlers = []
    
    # Create formatter
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler with rotation
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8"
    )
    file_handler.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    logger.info(f"Logging initialized. Log file: {log_file}")
    
    return logger


def log_order_request(
    logger: logging.Logger,
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float] = None,
    stop_price: Optional[float] = None
) -> None:
    """Log order request details.
    
    Args:
        logger: Logger instance
        symbol: Trading pair symbol
        side: Order side (BUY/SELL)
        order_type: Order type (MARKET/LIMIT/STOP_LIMIT)
        quantity: Order quantity
        price: Limit price (optional)
        stop_price: Stop price (optional)
    """
    log_msg = f"ORDER REQUEST | Symbol: {symbol} | Side: {side} | Type: {order_type} | Quantity: {quantity}"
    if price is not None:
        log_msg += f" | Price: {price}"
    if stop_price is not None:
        log_msg += f" | StopPrice: {stop_price}"
    logger.info(log_msg)


def log_order_response(
    logger: logging.Logger,
    response: dict,
    success: bool = True
) -> None:
    """Log order response details.
    
    Args:
        logger: Logger instance
        response: API response dictionary
        success: Whether the order was successful
    """
    if success:
        order_id = response.get("orderId", "N/A")
        status = response.get("status", "N/A")
        executed_qty = response.get("executedQty", "N/A")
        avg_price = response.get("avgPrice", "N/A")
        
        logger.info(
            f"ORDER RESPONSE | OrderId: {order_id} | Status: {status} | "
            f"ExecutedQty: {executed_qty} | AvgPrice: {avg_price}"
        )
    else:
        logger.error(f"ORDER FAILED | Response: {response}")


def log_api_error(logger: logging.Logger, error: Exception, context: str = "") -> None:
    """Log API error with context.
    
    Args:
        logger: Logger instance
        error: Exception that occurred
        context: Additional context about where the error occurred
    """
    error_msg = f"API ERROR: {str(error)}"
    if context:
        error_msg = f"{context} | {error_msg}"
    logger.error(error_msg, exc_info=True)
