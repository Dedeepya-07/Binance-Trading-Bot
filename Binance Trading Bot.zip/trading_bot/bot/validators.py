"""Input validation module.

Provides validation functions for trading parameters and order inputs.
"""

import re
from typing import Optional, Tuple
from enum import Enum


class OrderSide(Enum):
    """Valid order sides."""
    BUY = "BUY"
    SELL = "SELL"


class OrderType(Enum):
    """Valid order types."""
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_MARKET = "STOP_MARKET"
    TAKE_PROFIT = "TAKE_PROFIT"
    TAKE_PROFIT_MARKET = "TAKE_PROFIT_MARKET"
    STOP_LIMIT = "STOP_LIMIT"


class ValidationError(Exception):
    """Custom exception for validation errors."""
    pass


def validate_symbol(symbol: str) -> Tuple[bool, str]:
    """Validate trading symbol format.
    
    Binance Futures symbols follow the pattern: BASEQUOTE (e.g., BTCUSDT, ETHUSDT)
    
    Args:
        symbol: Trading pair symbol to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not symbol:
        return False, "Symbol cannot be empty"
    
    if not isinstance(symbol, str):
        return False, "Symbol must be a string"
    
    symbol = symbol.strip().upper()
    
    # Check format: 6-10 uppercase letters ending with USDT (common for futures)
    # Binance futures symbols are typically 6-12 characters
    if not re.match(r'^[A-Z]{3,10}USDT$', symbol):
        return False, (
            f"Invalid symbol format: '{symbol}'. "
            "Expected format: BASEQUOTE (e.g., BTCUSDT, ETHUSDT)"
        )
    
    return True, ""


def validate_side(side: str) -> Tuple[bool, str]:
    """Validate order side.
    
    Args:
        side: Order side to validate (BUY or SELL)
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not side:
        return False, "Side cannot be empty"
    
    side = side.strip().upper()
    
    try:
        OrderSide(side)
        return True, ""
    except ValueError:
        valid_sides = [s.value for s in OrderSide]
        return False, f"Invalid side: '{side}'. Must be one of: {', '.join(valid_sides)}"


def validate_order_type(order_type: str) -> Tuple[bool, str]:
    """Validate order type.
    
    Args:
        order_type: Order type to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not order_type:
        return False, "Order type cannot be empty"
    
    order_type = order_type.strip().upper()
    
    try:
        OrderType(order_type)
        return True, ""
    except ValueError:
        valid_types = [t.value for t in OrderType]
        return False, f"Invalid order type: '{order_type}'. Must be one of: {', '.join(valid_types)}"


def validate_quantity(quantity: float) -> Tuple[bool, str]:
    """Validate order quantity.
    
    Args:
        quantity: Order quantity to validate
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        qty = float(quantity)
    except (ValueError, TypeError):
        return False, f"Quantity must be a valid number, got: {quantity}"
    
    if qty <= 0:
        return False, f"Quantity must be greater than 0, got: {qty}"
    
    # Check for reasonable precision (max 8 decimal places for most futures)
    decimal_str = str(qty)
    if '.' in decimal_str:
        decimals = len(decimal_str.split('.')[1])
        if decimals > 8:
            return False, f"Quantity has too many decimal places (max 8), got: {qty}"
    
    return True, ""


def validate_price(price: Optional[float], order_type: str) -> Tuple[bool, str]:
    """Validate order price.
    
    Args:
        price: Order price to validate
        order_type: Type of order (price required for LIMIT orders)
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    order_type = order_type.strip().upper()
    
    # Price is required for LIMIT and STOP_LIMIT orders
    if order_type in ["LIMIT", "STOP_LIMIT"]:
        if price is None:
            return False, f"Price is required for {order_type} orders"
        
        try:
            price_val = float(price)
        except (ValueError, TypeError):
            return False, f"Price must be a valid number, got: {price}"
        
        if price_val <= 0:
            return False, f"Price must be greater than 0, got: {price_val}"
        
        return True, ""
    
    # For MARKET orders, price should not be provided
    if order_type == "MARKET" and price is not None:
        return False, "Price should not be provided for MARKET orders"
    
    return True, ""


def validate_stop_price(stop_price: Optional[float], order_type: str) -> Tuple[bool, str]:
    """Validate stop price for stop-limit orders.
    
    Args:
        stop_price: Stop price to validate
        order_type: Type of order
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    order_type = order_type.strip().upper()
    
    # Stop price is required for STOP_LIMIT orders
    if order_type == "STOP_LIMIT":
        if stop_price is None:
            return False, "Stop price is required for STOP_LIMIT orders"
        
        try:
            stop_val = float(stop_price)
        except (ValueError, TypeError):
            return False, f"Stop price must be a valid number, got: {stop_price}"
        
        if stop_val <= 0:
            return False, f"Stop price must be greater than 0, got: {stop_val}"
        
        return True, ""
    
    return True, ""


def validate_order_params(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float] = None,
    stop_price: Optional[float] = None
) -> None:
    """Validate all order parameters.
    
    Args:
        symbol: Trading pair symbol
        side: Order side (BUY/SELL)
        order_type: Order type (MARKET/LIMIT/STOP_LIMIT)
        quantity: Order quantity
        price: Limit price (optional)
        stop_price: Stop price (optional)
    
    Raises:
        ValidationError: If any validation fails
    """
    errors = []
    
    # Validate symbol
    is_valid, error = validate_symbol(symbol)
    if not is_valid:
        errors.append(error)
    
    # Validate side
    is_valid, error = validate_side(side)
    if not is_valid:
        errors.append(error)
    
    # Validate order type
    is_valid, error = validate_order_type(order_type)
    if not is_valid:
        errors.append(error)
    
    # Validate quantity
    is_valid, error = validate_quantity(quantity)
    if not is_valid:
        errors.append(error)
    
    # Validate price
    is_valid, error = validate_price(price, order_type)
    if not is_valid:
        errors.append(error)
    
    # Validate stop price
    is_valid, error = validate_stop_price(stop_price, order_type)
    if not is_valid:
        errors.append(error)
    
    if errors:
        raise ValidationError("Validation failed:\n- " + "\n- ".join(errors))


def get_validated_symbol(symbol: str) -> str:
    """Get validated and normalized symbol.
    
    Args:
        symbol: Raw symbol input
    
    Returns:
        Normalized uppercase symbol
    
    Raises:
        ValidationError: If validation fails
    """
    is_valid, error = validate_symbol(symbol)
    if not is_valid:
        raise ValidationError(error)
    return symbol.strip().upper()


def get_validated_side(side: str) -> str:
    """Get validated and normalized side.
    
    Args:
        side: Raw side input
    
    Returns:
        Normalized uppercase side
    
    Raises:
        ValidationError: If validation fails
    """
    is_valid, error = validate_side(side)
    if not is_valid:
        raise ValidationError(error)
    return side.strip().upper()


def get_validated_order_type(order_type: str) -> str:
    """Get validated and normalized order type.
    
    Args:
        order_type: Raw order type input
    
    Returns:
        Normalized uppercase order type
    
    Raises:
        ValidationError: If validation fails
    """
    is_valid, error = validate_order_type(order_type)
    if not is_valid:
        raise ValidationError(error)
    return order_type.strip().upper()
